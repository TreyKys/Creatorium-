import { google } from '@ai-sdk/google';
import { generateObject } from 'ai';
import { z } from 'zod';

// Allow longer timeout for complex generation
export const maxDuration = 60;

const FileSchema = z.object({
  name: z.string().describe('The file path, e.g., "sources/token.move", "frontend/App.tsx", or "deploy.sh"'),
  content: z.string().describe('The full content of the file'),
});

const ResponseSchema = z.object({
  explanation: z.string().describe('A markdown explanation of the architecture and code'),
  files: z.array(FileSchema).describe('The list of files to generate'),
  learn_content: z.string().describe('Detailed educational content explaining the Move concepts used in this project'),
});

export async function POST(req: Request) {
  try {
    const { prompt } = await req.json();

    // Use the API key from environment variables
    // const apiKey = process.env.GOOGLE_GENERATIVE_AI_API_KEY;

    const systemPrompt = `You are an expert Cedra/Move developer and a UI/UX engineer.
Your goal is to build a **PRODUCTION-READY** DApp on the Cedra Network.

When a user asks to build a DApp (e.g., "Build a prediction market"):
1.  **Analyze**: Break down the request into necessary Move modules and Frontend components.
2.  **Educate**: Explain your reasoning.
3.  **Generate**: detailed code for all files.

**CRITICAL REQUIREMENTS**:

### 1. Move Backend (The Smart Contract)
*   **Move.toml**:
    *   Dependency: \`[dependencies] CedraFramework = { git = "https://github.com/cedra-labs/cedra-framework.git", rev = "main" }\`.
    *   Addresses: \`[addresses] std = "0x1", cedra_framework = "0x2", creatorium = "0xCAFE"\`.
*   **Sources**:
    *   Generate robust modules in \`sources/\`.
    *   Use \`public entry fun\` for transactions.
    *   **Security**: Implement access control (Capabilities) and checks.

### 2. Frontend (The Web Interface)
*   **Structure**:
    *   Root: \`frontend/\`
    *   Entry: \`frontend/App.tsx\`
*   **Wallet Connection (PRODUCTION READY)**:
    *   Do NOT use mock buttons. Use the standard pattern for the **Cedra Wallet Adapter**.
    *   Assume \`import { useWallet } from "@cedra/wallet-adapter";\` and \`import { WalletProvider } from "@cedra/wallet-adapter-react";\`.
    *   The UI must have a real "Connect Wallet" button triggering the adapter.
*   **UI/UX**:
    *   Futuristic "Creatorium" aesthetic (Tailwind CSS).
    *   **Audit Status**: You MUST include a visible badge or status indicator in the UI that says **"AWAITING AUDIT"** (Yellow/Warning color). This is mandatory for safety.
*   **Components**:
    *   Break down complex logic into components if needed (e.g. \`frontend/components/MarketCard.tsx\`).

### 3. Deployment & Documentation
*   **deploy.sh**:
    *   Generate a shell script in the root.
    *   Content:
        \`\`\`bash
        #!/bin/bash
        echo "Building Cedra Move Contract..."
        cedra move build
        echo "Publishing to Cedra Network..."
        # Note: Ensure you have your wallet configured (cedra init)
        cedra move publish
        \`\`\`
*   **README.md**:
    *   Write a clear guide on how to:
        1.  Run \`sh deploy.sh\` to deploy the contract.
        2.  Update the frontend config with the new contract address.
        3.  Run \`npm install\` and \`npm start\` for the frontend.

**Response Format**:
Strictly return the JSON object matching the schema.
`;

    const result = await generateObject({
      model: google('gemini-3-pro-preview'),
      schema: ResponseSchema,
      system: systemPrompt,
      prompt: prompt,
    });

    return result.toJsonResponse();
  } catch (error) {
    console.error('AI Generation Error:', error);
    return new Response(JSON.stringify({ error: 'Failed to generate DApp. Please check API Key or Quota.' }), { status: 500 });
  }
}
