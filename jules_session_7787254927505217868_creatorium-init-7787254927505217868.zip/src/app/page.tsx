import CreatoriumLayout from "@/components/layout-shell";

export default function Home() {
  return <CreatoriumLayout />;
}
